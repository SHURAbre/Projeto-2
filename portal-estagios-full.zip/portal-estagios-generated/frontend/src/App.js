import React from "react";
import Areas from "./pages/Areas";
export default function App(){
  return (
    <div style={{fontFamily:'Arial, sans-serif', padding:20}}>
      <h1>Portal de Estágios - Frontend (skeleton)</h1>
      <Areas />
    </div>
  );
}
