Frontend skeleton (React)
- Instalar: npm install
- Rodar: npm start
- Configure REACT_APP_API_URL se o backend estiver em outra URL.
