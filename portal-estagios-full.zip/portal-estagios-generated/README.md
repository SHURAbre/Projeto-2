# Portal de Estágios - Pacote Gerado
Este .zip contém a **estrutura completa** do projeto (backend + frontend) com arquivos de exemplo e placeholders.
Objetivo: dar a você um projeto pronto para ajustar, compilar e rodar localmente.

**O que está incluído**
- backend/ (skeleton Spring Boot project files and examples)
- frontend/ (React skeleton)
- docs/ (diagrams placeholders)
- run.sh script

Leia `backend/README.md` e `frontend/README.md` para instruções rápidas.
