Backend skeleton
- Execução rápida (usando controller em memória): mvn spring-boot:run
- H2 console disponível em http://localhost:8080/h2-console
- Substitua controllers por implementações JPA quando quiser persistência real.
