#!/bin/bash
echo "Scripts:"
echo " - backend: cd backend && ./mvnw spring-boot:run"
echo " - frontend: cd frontend && npm install && npm start"
